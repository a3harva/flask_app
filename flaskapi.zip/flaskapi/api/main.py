import json
 

# json.dump(data,f)

print(data)



