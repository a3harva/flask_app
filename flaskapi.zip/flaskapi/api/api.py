import re
import flask
import json 
from flask import jsonify,request,render_template

app = flask.Flask(__name__)
app.config["DEBUG"] = True
import sqlite3
from datetime import datetime

def string_to_datetime(date_time_str):
    # date_time_str = '18-09-19'
    date_time_obj = datetime.strptime(date_time_str,'%d-%m-%Y')
    # print("the date is actually !!!!!!!!!!!!!!!",date_time_obj)
    return date_time_obj



# print ("The type of the date is now",  type(date_time_obj))
# print ("The date is", date_time_obj)



f = open('sample.json')
  

data = json.load(f)

def check_for_validity(string_email):
            for user_data_key in data.keys():
                if user_data_key == string_email:
                    return True
            return False

def data_to_list(data):
    emp_list=[]
    for emp in data:
        emp_list.append(data.keys())

    print(emp_list)

# data_to_list(data)

@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')

@app.route('/api/all', methods=['GET'])
def api_all():
    return jsonify(data)


@app.route('/api/employee', methods=['GET','POST','DELETE','PUT','PATCH'])
def api_id():

    


    if request.method =='GET':
        # print(request.args)   
        

        if 'email' in request.args and check_for_validity(str(request.args['email']))==False:
            return "user does not exist"


        elif 'email' in request.args and 'date_of_query' not in request.args:
            email = str(request.args['email'])


    # Create an empty list for our results
            results = []
            # print(data,'this is data')
            # Loop through the data and match results that fit the requested ID.
            # IDs are unique, but other fields might return many results
            for user_data_key in data.keys():
                if user_data_key == email:
                    results.append(data[user_data_key])
            return jsonify(results)

        elif 'email' in request.args and 'date_of_query' in request.args:
            # print("recieved email and date")   this works !!
            string_date=request.args['date_of_query']
            email = str(request.args['email'])
            # print(string_date)

            date_of_query_obj= string_to_datetime(string_date)
            
            print(date_of_query_obj)
            # print(data)
            for user_data_key in data.keys():
                if user_data_key==email:
                    for temp_data in data[user_data_key]:
                        from_date_obj=string_to_datetime(temp_data['from'])
                        to_date_obj=string_to_datetime(temp_data['to'])
                        
                        if date_of_query_obj <to_date_obj and date_of_query_obj>from_date_obj:
                            return temp_data['profile']
                    return "no profiles assigned to user for this date"
                        
                        # print(temp_data['from'])
                    # print(data[user_data_key])
        elif 'email' not in request.args:
            print("no user id given ")
            return 'no user id provided'

                    

            # return "date and email"
        

    elif request.method =='POST':
        print('post request recieved')

        return jsonify(data)

    elif request.method =='PUT':
        print('update request recieved')


        put_data=request.get_json()
        # print(put_data)

        employee_email=put_data['email']
        from_date_obj= string_to_datetime(put_data['from'])
        to_date_obj=string_to_datetime(put_data['to'])
        employee_profile=put_data['profile']
        if to_date_obj<from_date_obj:
            return "invalid date responses"
        if check_for_validity(str(employee_email)) is False:
            print('user does not exist insisde this json file')
            # data.append()
            temp_dict={
                "from": put_data['from'],
                "profile": put_data['to'],
                "to": put_data['profile']
            }
            data[employee_email]=[temp_dict]
            # print(data)
            with open("sample.json", "w") as outfile:
                        json.dump(data, outfile)
            
            return "new employee added"


        # print(employee_email,from_date_obj,to_date_obj,employee_profile)  this works 
        # print(data[employee_email])
        firstdate_obj=string_to_datetime(data[employee_email][0]['from'])
        # print(firstdate_obj)
        lastdate_obj=string_to_datetime(data[employee_email][-1]['to'])
        # print(lastdate_obj)
        for mail in data.keys():
            if mail==employee_email:
                if from_date_obj >= lastdate_obj:
                    data[employee_email].append({
                        "from":"",
                        "to":"",
                        "profile":""
                    })
                    data[employee_email][-1]['from']=put_data['from']
                    data[employee_email][-1]['to']=put_data['to']
                    data[employee_email][-1]['profile']=put_data['profile']

                    with open("sample.json", "w") as outfile:
                        json.dump(data, outfile)
                    
                if to_date_obj <= firstdate_obj:

                    dict_1={
                        "from":"",
                        "to":"",
                        "profile":""
                    }
                    dict_1['from']=put_data['from']
                    dict_1['to']=put_data['to']
                    dict_1['profile']=put_data['profile']

                    listone =[]
                    listone.append(dict_1)
                    # list_temp=data[employee_email]
                    # list_two=[dict_1]+list_temp
                    temp_list=listone+data[employee_email]
                    data[employee_email]=temp_list
                    print(data[employee_email])
                    
                    with open("sample.json", "w") as outfile:
                        json.dump(data, outfile)
                else:
                    for temp_data in data[employee_email]:
                        if temp_data['from']<=from_date_obj<=temp_data['to'] and temp_data['from']<=to_date_obj<=temp_data['to']:
                            #split the time frames in three first and third being originals and middle being new one 
                            #insert new item after the first one
                            #change to date of first one 
                            #insert another item after new item, with to date as original to date and from date as end of last object4

                            
                              


                            pass
                        else:
                            #for the cases when from date and two date are in diffrent dictonaries 

                            pass


        return jsonify(data)


app.run()